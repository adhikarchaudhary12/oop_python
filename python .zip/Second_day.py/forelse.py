fruits = ['orange','apple','mango'] #for else example
for index in range (len(fruits)):
    print(fruits[index])
else:
    print("Finished itterating over fruits")
    print("Programme terminate")