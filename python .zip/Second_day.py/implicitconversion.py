num_int = 123
num_float = 1.23
num_new = num_int + num_float
print("data type of num_int:",type(num_int))
print("data type of num_float:",type(num_float))

print("value of num_new:",(num_new))
print("datatype of num_new:",type(num_new))