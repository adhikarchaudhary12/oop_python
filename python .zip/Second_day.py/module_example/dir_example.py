import module1
print(dir(module1))

import math
print(dir(math))