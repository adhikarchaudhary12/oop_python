def module1_func():
    print("Hello adhikar")

def test1():
    print("print inside")