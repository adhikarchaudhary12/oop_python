def test():
    print("Hello")

test()

def test():
    print("hello1")

test()