def module2_func():
    print("Hello adhikar")

def test2():
    print("print inside")