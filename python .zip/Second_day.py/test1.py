def add(a,b):
    sum = a+b
    return sum
    
result = add(12,12)
print(result)
