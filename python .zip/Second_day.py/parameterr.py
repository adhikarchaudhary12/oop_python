def showName(name):#name parameter ho
    print("Hello {0}".format(name))

showName("adhikar")#adhikar argument 

def showAddress(address,phonenumber):
    print("Your address{0} and your phone number is {1}".format(address,phonenumber))

showName("Nepalgunj", 9804535524)