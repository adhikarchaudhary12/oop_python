print('Doing task one')
try:
    f = open("adhikar.txt", 'r')
    print(f.read())

except IOError as e:
    print("Io error")
    print(e)

print('Doing next task')