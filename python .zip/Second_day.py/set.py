#creating a set 
a={1,2,3}
print(a)
print(type(a))

#this will act as a dict
a={}
print(a)
print(type(a))

#empty set
a=set
print(a)
print(type(a))

#can consists of unique elements only
a={1,2,3,1}
print(a)

#iteration
a={1,2,3,1}
for items in a: 
    print(items)

#removing by temove

a={1,2,3,1}
a.remove(2)
#a.remove(2)#throws keyerror

#removing by discard
a={1,2,3,1}
a.discard(2)
a.discard(2)#does nothing 
print(a)

#union
a={1,2,3}
b={3,2,1}
c=a.union(b)
print(c)

#intersection
a={1,2,3}
b={3,2,1}
c=a.intersection(b)
print(c)

#difference,present in a but not in b
a={1,2,3}
b={3,2,1}
c=a.difference(b)
print(c)

#update function,adding all elements of b to a
a={1,2,3}
b={3,2,1}
c=a.update(b)
print(c)

#add elements
a={1,2,3}
a.add(4)
print(a)

#pop elements
a={1,2,3}
b=a.pop()
print(a)
print(b)