import math
def get_xy(x1,x2,y1,y2):
    x=x2-x1
    y=y2-y1
    return x,y

def distance(x1,x2,y1,y2): 
    x,y = get_xy(x1,x2,y1,y2)
    dsquared=x**2+y**2
    result=math.sqrt(dsquared)
    return result

d = distance(2,3,2,3)

print(d)