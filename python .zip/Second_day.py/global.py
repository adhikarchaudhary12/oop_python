def showAddition(*args):
    sum=0
    for arg in args:
        sum=sum+arg
    print("The sum is",sum)

sum=0
showAddition(20,30,20,00,140,150)
print("The total addition is:",sum)

def showInc
     