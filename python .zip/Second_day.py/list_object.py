
#string's case

'''
a = "banana"
b = "banana"
print(a == b)
print(a is b)
'''

#list's case
a = [1,2,3]
b = [1,2,3]
print(a == b)
print(a is b)
