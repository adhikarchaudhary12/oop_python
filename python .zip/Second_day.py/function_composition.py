'''def compose(f,g):
    return lambda x:f(g(x))

def add(x):
    return x+1

def multiply(x):
    return x*2

new_func = compose(add, multiply)
print(new_func(2))
'''
'''
def compose(*function)
    def compose(f,g):
        return lambda x:f(g(x))
    
    def add(x):
    return x+1

    def multiply(x):
    return x*2

new_func = compose(add, multiply)
print(new_func(2))
'''
def compose2(f,g)
    return lambda x: f(g(x))

def double(x):
    return x*2

def inc(x):
    return x+1

inc_and_double=compose2(double,inc)
print(inc_and_double(10))
