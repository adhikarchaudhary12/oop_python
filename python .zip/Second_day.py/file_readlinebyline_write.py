abc = open("test.txt","r")
while True:
    line = abc.readlsine()
    if len(line) == 0:
        break
    print(line)
abc.close()