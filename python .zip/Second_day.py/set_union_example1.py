a={1,2,3}
b={2,3,4}

union=a|b
intersection=a&b
difference=a-b

c={4,5,6}
multiple_union=a|b|c
print(multiple_union)
print(union)
print(intersection)
print(difference)
