'''
count = 1
while count <=10:
    print(count)
    count = count+1
else:
    print("Loop finished")
'''
'''
a ="Nepal"
count = 0
while count < len(a):
    character = a[count]
    print(character)
    count +=1
'''
'''
a = "Nepal"
for character in a:
    print(character)
'''
a = "Nepal"
for index in range(len(a)):
    character = a[index]
    print(character)

