'''
for letter in 'Adhikar':
    print('Current letter: ', letter)
'''
fruits = ['orange','apple','gova']
for index in range(len(fruits)):
    print(fruits[index])
