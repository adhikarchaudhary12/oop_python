age = 17
if age>=18:
    print("You can vote")