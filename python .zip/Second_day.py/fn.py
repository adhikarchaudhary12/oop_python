

def my_function(fname)
print(fname+"is pursuing BSc(Hons)Computing")
my_function("Adhikar")
my_function("Saimon")
my_function("Saugat")
my_function("Aashish")

def list_of_account_holder(fname,lname,address)
print(fname,lname,address+"is account holder of NIC asia bank")
list_of_account_holder("adhikar")
list_of_account_holder("aashish")
list_of_account_holder("saimon")
list_of_account_holder("saugat")
