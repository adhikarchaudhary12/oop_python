class CustomError(Exception):
    def  __init__(self,message,error):
        #call the base class constructor with the paremeters it needs
        super().__init__(message)

        #now for your custom code...
        self.errors=errors

a=12
if a>=10:
    raise CustomError("Not good," "must be less than 10 ")