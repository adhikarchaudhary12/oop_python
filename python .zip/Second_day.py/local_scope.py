def print_message():
    message="Hello i am learning python"#local scope 
    print(message)
print_message()


def print_message():

    message="Hello i am developer"
    print(message)
print_message()