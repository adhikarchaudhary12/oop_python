#if else example
food = 'spam'
if food == 'spam':
    print('Umm, my favourate!')
else:
    print("No, i wont have it i want spam!")