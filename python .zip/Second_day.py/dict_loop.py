#iteration
details = {'name': 'ram', 'age':24}
print(details.items())

for key,val in details.items():
    print(key, val)
#key
keys = details.keys()