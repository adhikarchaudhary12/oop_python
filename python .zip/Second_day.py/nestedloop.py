for cont in range(1,4):
    fruits = ['orange', 'mango']
    for c in range(len(fruits)):
        print(fruits[c])
    print(cont)