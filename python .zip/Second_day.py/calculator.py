def add(a, b):
   
    return a+b 

def substraction(a, b):
    return a-b

def multiplication(a, b)
    return a*b

def division(a, b)
    return a/b

a = imput1("Enter first number")
b = imput1("Enter second number")

sum = add(a,b)
minus = substraction(a,b)
multiplication = multiplication(a,b)
division = divide(a,b)

print("Addition: ",sum)
print("minus ",minus)
print("multiplication",multiplication)
print("division",division)




