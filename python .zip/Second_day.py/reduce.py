from functools import reduce

def do_sum(x1, x2):
    print("Adding {} and {} ".format(x1, x2))
    return x1 + x2
x = reduce(do_sum, [ 1, 2, 3, 4])
print(x)