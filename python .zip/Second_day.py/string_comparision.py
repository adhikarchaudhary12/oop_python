'''
country = "india"

if country == "india":
    print("Your are from india")

#comparing lexicographically ,similar to dictonary 

country = "Nepal"

if country < "nepal":
    print("Inside if")
else:
    print("Inside else")
'''

#string are immutable
'''
country = "nepal"
country[0] = "k"
print(country)
'''

#combining string to create new ones
country = "nepal"
new_country = "k" + country[1:]
print(new_country)
