myFile = open("data.txt","r")
myFile = ("My name is adhikar chaudhary\n")
myFile.write("My name is adhikar chaudhary\n")
myFile.close()