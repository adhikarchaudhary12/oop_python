a = [1,2,3]
b = a
print(a is b)

b[1] = 5
print(a)
print(b)