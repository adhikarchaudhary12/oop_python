import urllib.request
url = "https://www.onlinekhabar.com.txt/"
destination_filename = "url_data.txt"

urllib.request.urlretrieve(url,destination_filename)