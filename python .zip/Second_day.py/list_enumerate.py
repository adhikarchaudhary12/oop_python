numbers = [1,2,3,4]

for i, num in enumerate(numbers):
    print(i, num)