#in operator

vowels = 'aeiou'

text = 'nepal'

for char in text:
    if char in vowels: 
        print(char)