text = "Miss_12392509295%09"
digit_count=0
alphabets_count=0
symbols_count=0
for character in text:
    if character.isdigit():
        digit_count=digit_count+1
    elif character.isalpha():
        alphabets_count=alphabets_count+1
    else:
        symbols_count =symbols_count+1
print("Numbers of alphabets",alphabets_count)
print("Numbers of alphabets",digit_count)
print("Numbers of alphabets",symbols_count)