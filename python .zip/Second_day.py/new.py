name="Herald"
age=20
message="Hello this is herald college %s and my age is %d"%(name,age)
print(message)