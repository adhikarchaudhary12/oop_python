''''
def absolute_value(x):
    if x < 0:
        return -x
    else:
        return x
'''
'''
def calculate(a,b):
    sum = a+b
    substraction = a-b
    return sum,substraction
result1 = calculate(1,2)
print(result1) #result touple banayara display gardencha 
'''
def calculate(a,b):
    sum = a+b
    substraction = a-b
    return sum,substraction
result1,result2 = calculate(1,2)
print(result1)
print(result2)
