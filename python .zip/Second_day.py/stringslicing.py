a = "Nepal"

print(a[2:4]) # start dakhe end samma
print(a[:3])  #index 3 bhanda agadi ko
print(a[:2])
print(a[:])

#stringslicing
