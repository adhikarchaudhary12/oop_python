#tuple to list
a=(1,2,3)
b=list(a)
print(b)
print(type(b))

#list to touple
a=(1,2,3)
b=tuple(a)
print(b)
print(type(b))

#tuple to dict
t=(('name', 'test'), ('age',23))
d = dict((x,y) for x,y in t)
print(d)
print(type(d))

#dict to touple
d ={'name': 'test','age':23}
t = tuple(d.items())
print(t)
print(type(t))

d ={'name': 'test','age':23}