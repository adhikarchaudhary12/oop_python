file = open("Sortedfriends.txt", "r")
print(file.read(4))