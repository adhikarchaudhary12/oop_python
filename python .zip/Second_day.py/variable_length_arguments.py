def test(**kwargs):
    print(type(kwargs))
    print(kwargs)
    print(kwargs["name"])

test(name= "ram" ,age=20)

#sequence variable 
def test(a,b,*c,d,**kwargs):
    print(a)
    print(b)
    print(c)
    print(d)
    print(kwargs)
test(1,2,3,4,5,d=6,name="adhikar")