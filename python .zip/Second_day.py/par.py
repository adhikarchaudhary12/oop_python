def showName(name,phone):
    print("Your name is {0}, and your phone numbe is {1}".format(name,phone))

showName("adhiikar", 9804535524)

#mutable
#defining the  function 
def change_list(list1):
    list1.append(20)
    list1.append(30)
    print("list inside function = ",list1)

#defining the list
list = [10,30,40,50]

#calling the function 
change_list(list1)


print("list outside function = ", list1)