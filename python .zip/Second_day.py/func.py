def printadhikar(str):
    "Hello this is me adhikar chaudhary"
    print(str)
    return