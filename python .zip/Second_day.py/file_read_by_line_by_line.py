f = open("friends.txt","r")
xs = f.readlines()
f.close()

xs.sort()
g = open("Sortedfriends.txt","w")
for v in xs:
    g.write(v)
g.close