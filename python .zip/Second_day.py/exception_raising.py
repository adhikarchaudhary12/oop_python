def validate_age(age):
    if age<=18:
        error=ValueError("Your are not elligable for vote !You must me greater than 18")
        raise error
    print("Your age is : ")

age=int(input("Enter your ag"))
validate_age(age)