import datetime
def fibo(n):
    if n <=1:
       return n
    else:
        return fibo(n-1) + fibo(n-2)
nterms = 35
print("Fibonacci sequece: ")
start_time = datetime.datetime.now()
for i in range(nterms):
    print(fibo(i))

end_time = datetime.datetime.now()
time_diff = end_time - start_time
print(time_diff)
