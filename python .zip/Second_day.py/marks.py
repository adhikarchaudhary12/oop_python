total_marks= 800
total_subject= 8
marks = 640
total=(total_marks/marks)*100
if total>=80:
    print("Your marks is Distinction")
elif total>=70:
    print("Your marks is first division")
elif total>=60:
    print("your marks is less than first division")
