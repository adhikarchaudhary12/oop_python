'''
for i in range(20):
    if i %2 == 0:
         print(i)
'''
'''
for i in range(2,10):
    print (i)
    '''
    '''
 for i in range(2, 10, 3):
     print (i)
     '''
for letter in 'Adhikar':
    print('Current letter: ', letter)