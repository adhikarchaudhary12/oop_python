#defining the function
def func(name):
    print("Hi",name)
#calling the function 
func("aadhikar")
