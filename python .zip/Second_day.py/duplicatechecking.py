numbers = [1,3,9,8,3,1,7,4,8]
for i in range(len(numbers)):
    for j in range(len(numbers)):
        if i !=j and i<j and numbers[i] == numbers[j]:
            print("You are duplicate number:",numbers[j])
            