'''
a = [3,4,"Nepal"]#touple unpacking
(number1,number2,country) = a
print(number1,number2,country)
'''
#exchanging values of two variable with out touple
a = 2
b = 3
temp = a
a = b
b = temp

#exchanging values of two variables ,with touple

a=2
b=3
(a,b)=(b,a)
print(a,b)