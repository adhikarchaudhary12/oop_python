numbers = [1,2,3,4]
numbers[1] = 9
print(numbers)