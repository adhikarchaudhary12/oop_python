import datetime
memo = {0:0, 1:1}
def fibonacci(n):
    if n in memo:
       return memo[n]
    else:
        result = fibonacci(n-1) + fibonacci(n-2)
        memo[n] = result
        return result
nterms = 35
print("Fibonacci sequece: ")
start_time = datetime.datetime.now()
for i in range(nterms):
    print(fibonacci(i))

end_time = datetime.datetime.now()
time_diff = end_time - start_time
print(time_diff)
