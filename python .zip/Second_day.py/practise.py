name="adhikar"
age= 22
print("my name is",name," my age is ",age)


name="adhikar"
age=22
message="my name is {0} and my age is {1}".format(name,age)

name ="adhikar"
age=20
education="BSc(Hons)computer science"
message="my name is %s and my age is %d and my education is %s "% (name,age,education)
print(message)

address="Nepalgunj"
ward=10
Municapility="Nepalgunj sub metro politian "
message="My address is %s and my ward is %d and my Municapility is %s"%(address,ward,Municapility)
print(message)