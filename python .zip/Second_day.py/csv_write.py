import csv
with open('employee_file.csv', mode='w') as employee_file:
    employee_writer = csv.writer(employee_file, delimiter=',',
        quotechar='"', quoting=csv.QUOTE_ALL)
    employee_writer.writerow(['Emp_name','Department','Date_of_birth'])
    employee_writer.writerow(['Adhikar','IT','August'])
    employee_writer.writerow(['Saimpn','Marketing','June'])
    employee_writer.writerow(['Saugat','Human Resource','Dec'])
    employee_writer.writerow(['Aashish','Account','Feb'])
