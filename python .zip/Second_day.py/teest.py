def task3():
    print("Task3")
    return 2

def task2():
    print("Task2")
    a=task3()
    print(a)
    return 5

def task1():
    print("task1")
    a = task2()
    print(a)
    return 6

result = task1()
print(result)
