#simple assertion
'''
a = 13
assert a == 13
print("done")
'''

#raising an exception if assertion is false
'''
a = 13
assert a == 12, "Value is not equal to 12"
print("done")
'''

#previous example of age validation without raise keyword
def validate_age(age):
    assert age >= 18, "Age mus be greater than 17 to vote."
    print("Your age is vaid")
validate_age(17)