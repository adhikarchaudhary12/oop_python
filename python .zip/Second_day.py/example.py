a = { "name": "ram","age": 24,"address": "bhaktapur","class":10,"height":6}
print(a.get('address'))
print(a.)