choice = 'c'
if choice == 'a':
    print("You chose 'a'.")
elif choice == 'b':
    print("You chose 'b' .")
elif choice == 'c':
    print("You chose 'c' .")
else:
    print("Invalid choice.")
