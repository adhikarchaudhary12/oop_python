def showName(name):
    print("Hello {0}".format(name))

showName("adhikar chaudhary")