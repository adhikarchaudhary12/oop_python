def test(**kwargs):
    print(type(kwargs))
    