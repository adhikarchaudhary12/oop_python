f = open("Capture.PNG", "rb")#originl file
g = open("copy.png", "wb")#file copy gara ko original file

while True:
    buf = f.read(1024)
    if len(buf) == 0:
        break
    g.write(buf)
f.close()
g.close()