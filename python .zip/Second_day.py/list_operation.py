list = [1,2,3]
print("before deleting",list)

del list[1]
print("after deleting",list)