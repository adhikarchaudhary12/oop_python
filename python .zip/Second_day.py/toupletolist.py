a = (1,2,3,4)# touple to list 
b = list(a)


print(b)
print(type(a))
print(type(b))

#list to touple
a = (1,2,3,4)
b = tuple(a)

print(b)
print(type(a))
print(type(b))