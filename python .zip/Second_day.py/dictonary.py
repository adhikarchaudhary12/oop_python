#creating an empty dictonary
details = {}

#dictonary with pairs
details = {"address":"ktm","birthday":1992}

#adding value to it
details["name"] = "ram"
details["birthday"] = 1990

print(details)
print(type(details))
#accessing specific value

val = details["name"]
print(val)
print(details.keys())
print(details.values())

#deletin a pair
details.clear()
print(details)

#deleting all items
details.clear()
print(details)

#len returns the number of pairs
details["name"] = "ram"
print(len(details))