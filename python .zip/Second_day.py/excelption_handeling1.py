#catching multiple exceptions in one except
try:
    a=[]
    result = a[0]
except(IndexError,ArithmeticError):
    print("Exception")
else:
    print("No Execution")

#using else block
try:
    a=[]
    #result = a[0]
  
except(IndexError,ArithmeticError):
    print("Exception")
else:
    print("No Execution")

#using finally block
#finally ma error bhaya pane na bhaya pane jancha ane print garcha 

try:
    a=[]
    result = a[0]
except(IndexError,ArithmeticError):
    print("Exception")
else:
    print("No Execution")
finally:
    print("Finally clearing")