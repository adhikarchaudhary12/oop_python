from functools import reduce

def compose(*functions):#variable length #types touple
    def compose2(f,g):
        print("combining {} and {}".format(f,g))
        return lambda x:  f(g(x))
    return reduce(compose2, functions)

def double(x):
    return x*2

def inc(x):
    return x+1
 
def dec(x):
     return x-1

inc_double_and_dec = compose(dec,double,inc)
x = inc_double_and_dec(10)
print(x)    