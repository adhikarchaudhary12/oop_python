sum = 2
def test():
    print(sum)

test()
print(sum)

#global variable
sum = 0
def test():
    global sum #global sum is compulsary in global variable while assigning 
    sum = sum +2
    print("Inside the function",sum)

test()
print("outside the function:",sum)