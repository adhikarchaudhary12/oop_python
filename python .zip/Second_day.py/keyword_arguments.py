#default argument 
def showName(name,age):
    print(name)
    print(age)
showName("adhikar",20)

#another way to pass keywords #keyword argument

def showName(name,age):
    print(name)
    print(age)

showName(age = 20, name ="adhikar chaudhary")

#default argument 
def showName(name,age=20):
    print(name)
    print(age)

showName("adhikar chaudhary")

def showName(*names):
    print(names)

showName("adhikar","hari")

#touple variables length
def display(*args):
    print(type(args))
    print(args)
display(1,2,3,4)
display(5,6)

#sequence kwargs
def print_kwargs(**kwargs):
        print(kwargs)

print_kwargs(kwargs_1="Shark", kwargs_2=4.5, kwargs_3=True)

def showName(name,age):
        print(name)
        print(age)
showName(name="adhikar",age=20)