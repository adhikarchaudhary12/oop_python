import sys
sys.path.append("../../")

 #fist example
from modules.test import test
test()