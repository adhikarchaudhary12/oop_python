'''
def test():
    print("Hello broaway")

print("Executing the task")
'''
def test ():
    print("Hello adhikar")

if __name__ =="__main__":
    print("Hello kathmandu")