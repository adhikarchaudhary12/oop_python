
#reverse loopup
a = {'name':'test','age':34}
for key, val in a.items():
    if val == 34:
        print(key)
        break


#for loop for reverse loop
'''
a = [1,2,3]
b = [num*2 for num in a]
print(b)
'''
#seconf approach,mapping for value to key

inverse_dict = dict((value,key) for key, value in a.items())
print(inverse_dict)
print(inverse_dict[34])