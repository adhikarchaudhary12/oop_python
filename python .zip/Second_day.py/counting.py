letters = "Mississippi"
letter_counts = {}
 
for index in range(len(letters)):
     letter = letters[index]
     letter_counts[letter] = letter_counts.get(letter, 0) + 1
print(letter_counts)
