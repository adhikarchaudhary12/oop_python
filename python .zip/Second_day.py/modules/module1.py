def sum(a,b):
    return a + b

def substraction(a,b):
    return a - b

def _test():
    print("inside test")

name = "broadway"
_address = "tinkune"

print("existing module1's own task")

