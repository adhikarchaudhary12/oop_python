a = 10
b = 34
result=a+b
print(result)