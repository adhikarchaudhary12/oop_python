#this is the first way to importing entire module 
#modules bhitra ko module1 and module 2 ma import garda
'''
import module1
sum_result = module1.sum(1,1)
substraction_result = module1.substraction(1,1)

print("sum", sum_result)
print("substraction",substraction_result)
print("name",module1.name)
print("address",module1._address)
module1._test()

#second way to importing selected one from module

from module1 import sum,substraction,_test,name,_address
sum_result = sum(1,1)
substraction_result = substraction(1,1)

print("sum",sum_result)
print("substraction",substraction_result)
print("name",name)
print("address",_address)
_test()
'''
#thirdway,imports all expect functions startin with _*
'''
from module1 import *

sum_result = sum(1,1)
substraction_result = substraction(1,1)
print("sum",sum_result)
print("substraction",substraction_result)
print("name",name)
print("address",_address)
_test()
'''

#import by renaming
from module1 import sum as add, substraction as minus , name as n, _address as a

sum_result = add(1,1)
substraction_result = minus(1,1)

print("sum", sum_result)
print("substraction", substraction_result)
print("name",n)
print("address",a)