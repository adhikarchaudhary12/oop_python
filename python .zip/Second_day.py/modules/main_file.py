#first way
'''
from package1 import module1,module2

module1.module1_func()
module2.module2_func()
'''
#second way
'''
import package1.module1, package1.module2

package1.module1.module1_func()
package1.module2.module2_func()
'''
#thirdway
'''
from package1.module1 import module1_func
from package1.module2 import module2_func
module1_func()
module2_func()
'''
#import * will only import those modules mentoined in init.py
from package1 import *
module1.module1_func()
module2.module2_func()
