def change_string(str):
    str = str +"Hello how are you"
    print("Printing the string outside function :",str)

string1 = "Hi i am here"

#calling the function 
change_string(string1)

print("Printing the string outside function:", string1)

def adhikar(str)
str=str+"You are student of BSc(Hons)Computing"
print("Hellop",str)
