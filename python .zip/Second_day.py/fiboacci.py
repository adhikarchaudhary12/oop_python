nterms = 20
n1 = 0
n2 = 1

if nterms ==1:
    print(n1)
else:
    for i in range (nterms):
        print(n1,"\n")
        nth = n1 + n2
        n1 = n2
        n2 = nth