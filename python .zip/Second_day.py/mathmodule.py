import math
a = math.sqrt(4)
print(a)