import csv

with open('test.csv',mode='r') as csv_file:
    csv_reader = csv.DictReader(csv_file)
    for row in csv_reader:
        '''
        gives order as output. OrderDict is similar to normal python dictonary,
        but in cas of orderDict the key are order.
        '''
        print(row)
        '''
        gives normal python as output
        '''
        print(dict(row))