def hello_world():
    print("Helo adhikar")#function part #indentation#jaila 4 ota space
    print("Hello herald")
 print("Outside the function")#outside the function 
 
hello_world()

