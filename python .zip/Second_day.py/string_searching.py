''''
def search(text, char):
    index = 0
    while index < len(text):
        if text[index] == char:
            return index
        index = index +1
    return -1

text = "I am in nepal"
position = search(text,"n")
print(position)
'''
#checking upper case and lower case
char = 'n'
text = 'I am a boy'
char_result= char.islower()
text_result= text.islower()
print(char_result)
print(char_result)

