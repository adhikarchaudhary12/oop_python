'''
print("Doing task1")
a=12/0
print("Doing task2")

'''
'''
#task2
try:
    a=12/0
except:
    print("Exception")
print("Doing task 3")

#task 3
try:
    print("Befor dividing 12 by 0")
    a=12/0
    print("After dividing")
except:
    print("Exception")
print("Doing task 3")
'''

print("Doing task 1")

#task 2
'''
try:
    
   # b=12/0
   a=[]
   print(a[1])
except IndexError as ie:
    print("index occured")
    print(ie)
except ZeroDivisionError as zde:
    print("zero division error")
    print(zde)#error map garna ko lage
except:
    print("other exception")
print("Doing task 3")
'''
#catching multiple exceptions in one except
try:
    a=[]
    result = a[0]
except(IndexError,ArithmeticError):
    print("Exception")