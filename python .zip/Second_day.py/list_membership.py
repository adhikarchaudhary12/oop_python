#membership
a = [1,2,3]
number1 = 2
number2 = 5

if number1 in a:
    print("2 is present in list")
if number2 not in a:
    print("5 is not present in list")