def is_even(x):
    if x % 2 ==0:
        return true
    else:
        return false

result = is_even(4)
print(result)