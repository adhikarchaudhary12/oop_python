def calculator(*args):
    sum=0
    for arg in args:
        sum=sum+arg
    print("The sum is",sum)

sum=0
calculator(10,20,30)
print("value of sum outside the function:",sum)

def calculator(*args):
    sum=0
    for arg in args:
        sum=sum+arg
    print("The sum is ",sum)

sum=0
calculator(20,34)
print("value of the sum the function:",sum)

a=30
b=40
c=40
result=a*b+c
print(result)
