'''
fruits = ['apple','orange','mango']

for fruit in fruits:
     print(fruit)
     if fruits =='orange':
         print("Fruit is orange.so, breaking for loop")
         break
print("Loop complete") #orange pache ko kunai pane print hudaina 
'''
fruits = ['apple','orange','mango']
for fruit in fruits:
           if fruit == 'orange':
                continue
            print(fruit)