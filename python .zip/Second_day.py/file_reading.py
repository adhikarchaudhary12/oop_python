f = open("test.txt", "r")
content = f.read()
f.close
print(content)