'''
count = 1
while count <= 10:
    print(count)
    count = count+1
'''
count = 20
while count <=30:
    if count % 2 ==0:
        print(count)
    count = count+1
    