def showName(name,age):
        print(name)
        print(age)
showName(name="adhikar",age=20)# this was way to pass keyword arguments

def showName(*names):
    print(names)
showName("adhikar","ram","sita")

