a = 2
b = 4.0

print("Data type of a", type(a))
print("Data type of b", type(b))

converted_a = float(a)
sum = converted_a + b

print("Data type of a  after conversion", type(converted_a))
print("sum",sum)
print("Data type of sum", type(sum))

