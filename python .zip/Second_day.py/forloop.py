fruits = ['apple','Mango','orange']
for fruit in fruits:
    print('Current fruits :',fruit)