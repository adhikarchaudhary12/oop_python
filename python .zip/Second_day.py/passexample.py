day = "saturday"
if day == "saturday":
    print("today is holiday. i want to watch movie")
else:
    pass
#pass lekha else ko statement execute hudaina 