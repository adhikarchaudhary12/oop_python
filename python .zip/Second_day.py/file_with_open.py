with open("Sortedfriends.txt","r") as f:
    print(f.read()) #file open gara close na garda ne huncha automatic huncha banda