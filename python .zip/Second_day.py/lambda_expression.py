a = lambda x: x+1
print(a(3))