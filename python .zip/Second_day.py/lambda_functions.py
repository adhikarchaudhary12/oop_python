a = lambda x,y: x+y
