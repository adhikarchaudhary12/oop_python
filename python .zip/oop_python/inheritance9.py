#calling parent's constructor
class Employee:
    def __init__(self,salary):
        self.salary = salary


class BankEmployee:
    def __init__(self, name,salary):
        super().__init__() #parent cass constructor calling
        self.name = name

emp = BankEmployee("Ram",1000)

print(emp.salary)