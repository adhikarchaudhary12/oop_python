#protected members can only be accessed from its child class.
#its just a convention, not a rule.whenever a programmer sees single underscore before a variable
#he tries not tp access its outside of the class and its child class

class Employee:
    def __init__(self, name):
        self._salary=2000
        self.name=name
class BankEmployee(Employee):
    
    def show(self):
        print(self._salary)

e1 = BankEmployee("Ram")

e1.show()
print(e1._salary)