#calling parent's constructor with parameters

class Employee:
    def __init__(self,salary):
        self.salary = salary
        self.position = position
        self.department = department

class BankEmployee(Employee):
    def __init__(self,name,sal):
        super().__init__(sal)
        self.name = name
        print(self.salary)
        print(self.department)
emp = BankEmployee("Ram", 2000) 
print(emp.department)       