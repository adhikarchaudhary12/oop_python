#public members can be accessed outside of the class using its objects.

class Employee:
    def __init__(self, name, sal):
        self.name=name
        self.salary=sal
e1 = Employee("Ram",2000)
print(e1.salary)