#multiple inheritance
class Animal:
    def speak(self):
        print("Animal speaking")

class Dog:
    def bark(self):
        print("Dog barking")

#The child class tommy inherits class dog and animals

class Tommy:
    def eat(Animal,Dog):
        print("Tommy eating meat...")
d = Tommy()
d.eat()
d.bark()
d.speak()