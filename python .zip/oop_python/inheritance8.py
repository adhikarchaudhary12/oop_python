#real world example of method overriding 

class Bank:
    def get_intrest_rate(self):
        return 10;

class SBI(Bank):
    def get_intrest_rate(self):
        return 7;

class ICICI(Bank):
    def get_intrest_rate(self):
        return 8;

class Nabil(Bank):
    pass

b1 = Bank()
b2 = SBI()
b3 = ICICI()
b4 = Nabil()
print("Bank rate of intrest:",b1.get_intrest_rate());
print("SBI rate of intrest:",b2.get_intrest_rate());
print("ICCI rate of intrest:",b3.get_intrest_rate());
print("Nabil rate of intrest:",b4.get_intrest_rate());
