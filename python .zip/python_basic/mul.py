a =2
b =3
result=a*2
print(result)