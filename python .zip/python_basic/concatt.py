name="adhikar"
age=22
message="my name is adhikar{0} and my age is {1}".format(name,age)
print(message)
# Next way with position 
name="adhikar"
age=22
message="my name is {1} and my age is {0}".format(age,name)
print(message)
#data foramt specifier 
name ="adhikar"
age=20
education="BSc(Hons)computer science"
message="my name is %s and my age is %d and my education is %s "% (name,age,education)
print(message)

# Next way
name="adhikar"
age=20
message="my name is %d and my age is %s"%(name,age)
print(message)
#
name="Herald"
age=20
message="my name is %d and my age is %s" %(name,age)
print(message)
name = "adhikar"
age=22
message="my name is %s and my age is %d"%(name,age)
print(message)
