name ="adhikar"
age=22
message="my age is {} and my age is{}".format(name,age)
print(message)


