name="adhikar"
age= 22
print("my name is",name," my age is ",age)
