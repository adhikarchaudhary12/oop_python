'''
hello
'''
print("Hello")
# adding two number
a = 1
b = 2
result=a+b
print(result)
