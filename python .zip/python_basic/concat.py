name="adhikar"
age=22
message="My name is" +name+"and my age is"+str(age)
print(message)
#string conatination 
