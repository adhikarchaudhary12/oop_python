a = input("Enter your name")
print(a)